//
//  ViewController.m
//  DXwhiteboxForiOS
//
//  Created by 飞奔的羊 on 2020/8/14.
//  Copyright © 2020 飞奔的羊. All rights reserved.
//

#import "ViewController.h"
#import "DXWhiteBoxManager.h"
@interface ViewController ()<DXWhiteBoxManagerStreamDelegate>

@property (weak, nonatomic) IBOutlet UITextField *InputKeyTextField;

@property (weak, nonatomic) IBOutlet UITextField *InputTextField;

@property (weak, nonatomic) IBOutlet UILabel *EncryptLabel;

@property (weak, nonatomic) IBOutlet UILabel *DecryptLabel;

@property (weak, nonatomic) IBOutlet UIButton *StartButton;
@property (weak, nonatomic) IBOutlet UIPickerView *InputView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [DXWhiteBoxManager protection:@""];
 
}
- (IBAction)Encrypt:(id)sender {
       // 待加密/加签的数据
    NSString *InStr = ![self.InputTextField.text isEqualToString:@""]?self.InputTextField.text:@"dingxiang-hello";
    NSData *testData = [InStr dataUsingEncoding:NSUTF8StringEncoding];
    NSData *testDataEncrypted;
    NSData *testDataDecrypted;
        NSString *key = self.InputKeyTextField.text;
    if ([self.InputKeyTextField.text isEqualToString:@""] || [self.InputKeyTextField.text isEqualToString:@"Random"]) {
        
        testDataEncrypted = [DXWhiteBoxManager encrypt:testData];
        testDataDecrypted = [DXWhiteBoxManager decrypt:testDataEncrypted];
        self.InputKeyTextField.text = @"Random";
    }else{
        testDataEncrypted = [DXWhiteBoxManager encrypt:testData withKey:key];
        testDataDecrypted = [DXWhiteBoxManager decrypt:testDataEncrypted withKey:key];
    }
        const char * EncryptedChar=[testDataEncrypted bytes];
        NSString *DecryptedStr =[[NSString alloc] initWithData:testDataDecrypted encoding:NSUTF8StringEncoding];
        self.EncryptLabel.text = [NSString stringWithFormat:@"Encrypted(char):%s",EncryptedChar];
        self.DecryptLabel.text = [NSString stringWithFormat:@"Decrypted:%@",DecryptedStr];
    if ([key isEqualToString:@"k1"]||[key isEqualToString:@"k2"]||[key isEqualToString:@"k3"]||[key isEqualToString:@"k7"]||[key isEqualToString:@"k8"]) {
             BOOL ver = YES;
                    NSString *ssss;
                    testDataEncrypted = [DXWhiteBoxManager encrypt:testData withKey:key];
                    ssss = [DXWhiteBoxManager sign:testData withKey:key];
                    ver = [DXWhiteBoxManager verify:testData withKey:key andSig:ssss];
                    self.EncryptLabel.text = [NSString stringWithFormat:@"Sign:%@",ssss];
                    if (ver) {
                        self.DecryptLabel.text = @"Success";
                    }else{
                        self.DecryptLabel.text = @"Faild";
                    }
                    
    }
        
        
    
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.InputKeyTextField endEditing:YES];
    [self.InputTextField endEditing:YES];

}
@end
