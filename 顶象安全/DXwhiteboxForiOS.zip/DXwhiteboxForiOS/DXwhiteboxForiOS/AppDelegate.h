//
//  AppDelegate.h
//  DXwhiteboxForiOS
//
//  Created by 飞奔的羊 on 2020/8/14.
//  Copyright © 2020 飞奔的羊. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

///Users/zyahs/Desktop/SDKO/demo/DXwhiteboxForiOS/DXwhiteboxForiOS/other_file
@end

