//
//  SceneDelegate.h
//  DXwhiteboxForiOS
//
//  Created by 飞奔的羊 on 2020/8/14.
//  Copyright © 2020 飞奔的羊. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

